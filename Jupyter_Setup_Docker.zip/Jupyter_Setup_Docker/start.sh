#!/bin/bash
sed -i 's/#c.NotebookApp.tornado_settings/c.NotebookApp.tornado_settings/' /root/.jupyter/jupyter_notebook_config.py
sed -i "/^c.NotebookApp.tornado_settings/s/=.*$/={'headers': {'Content-Security-Policy': \"frame-ancestors * \"}}/" /root/.jupyter/jupyter_notebook_config.py
jupyter notebook --ip=0.0.0.0 --port=8888 --NotebookApp.token='' --NotebookApp.password='' --allow-root &
while true
do
        sleep 60s
done
